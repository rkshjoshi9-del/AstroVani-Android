# AstroVani Android — source project

AstroVani by Rakesh Joshi is currently a free Android WebView wrapper around the AstroVani offline-first preview.

## What this build includes
- Android launcher app project (Kotlin + Android Gradle Plugin)
- Burgundy/cream AstroVani interface
- English, Hindi and Marathi interface selection
- Birth-profile create/edit/delete and local browser storage
- Kundli workspace shell, Panchang and reports placeholders
- Offline app assets bundled inside the APK
- GitHub Actions workflow to build a debug APK without a paid Lovable plan

## Important limitations
- This is an early Android prototype, not a production astrology app.
- Real planetary longitudes, Lahiri ayanamsa, divisional charts, Vimshottari dasha and Panchang are NOT implemented. The app clearly marks these as unavailable instead of fabricating results.
- Login/cloud sync, verified PDF reports, Kundli matching, release signing and Play Store publication are not implemented.
- The backup export uses browser Blob downloads; this Android wrapper does not yet provide a native file-save bridge. Restore via Android file picker is wired, but must be tested on a device.

## Build a debug APK
Requires Android Studio or Android SDK + JDK 17 + Gradle 8.9.

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build with free GitHub Actions
1. Create a public or private GitHub repository named `astrovani-android`.
2. Upload the complete contents of this folder to the repository root.
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Run **Build AstroVani Android APK** (or push to `main`).
5. Download the `AstroVani-debug-apk` artifact from the completed workflow run.

No Lovable credits are needed. Do not commit signing keys, passwords, or API tokens.
